<!DOCTYPE html>
<html>
<head>
	<title> </title>
</head>
<body>
<div id="flappy-bird-reborn"></div>
  <script src="js/phaser.min.js"></script>
  <script src="game/game.js"></script>
</body>
</html>