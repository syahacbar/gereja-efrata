'use strict';

function Menu(){

}

Menu.prototype= {
	preload: function() {

	},

	create: function() {
		this.background= this.game.add.sprite(0,0,'backgroud');

	},

	update: function() {

	}
};

module.exports = Menu;